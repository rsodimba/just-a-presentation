CREATE DATABASE BowlingAlleyDB
GO
USE BowlingAlleyDB
GO
IF OBJECT_ID('Reservations') IS NOT NULL
DROP TABLE Reservations
GO
IF OBJECT_ID('BookingSlots') IS NOT NULL
DROP TABLE BookingSlots
GO
IF OBJECT_ID('Roles') IS NOT NULL
DROP TABLE Roles
GO


IF OBJECT_ID('usp_BookSlots') IS NOT NULL
DROP PROC usp_BookSlots
GO

IF OBJECT_ID('ufn_FetchAllRejectedSlots') IS NOT NULL
DROP FUNCTION ufn_FetchAllRejectedSlots
GO

IF OBJECT_ID('ufn_GetAdminName') IS NOT NULL
DROP FUNCTION ufn_GetAdminName
GO

CREATE TABLE BookingSlots
(
	SlotId INT CONSTRAINT PK_BookingSlots PRIMARY KEY IDENTITY (1,1),
	SlotStartTime TIME(7) NOT NULL,
	SlotEndTime TIME(7) NOT NULL 
)

SET IDENTITY_INSERT BookingSlots ON
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (1,'09:00:00', '09:30:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (2,'09:30:00', '10:00:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (3,'10:00:00', '10:30:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (4,'10:30:00', '11:00:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (5,'11:00:00', '11:30:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (6,'14:00:00', '14:30:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (7,'14:30:00', '15:00:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (8,'15:00:00', '15:30:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (9,'15:30:00', '16:00:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (10,'16:00:00', '16:30:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (11,'16:30:00', '17:00:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (12,'17:00:00', '17:30:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (13,'17:30:00', '18:00:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (14,'18:00:00', '18:30:00')
INSERT INTO BookingSlots(SlotId, SlotStartTime, SlotEndTime) VALUES (15,'18:30:00', '19:00:00')
SET IDENTITY_INSERT BookingSlots OFF


CREATE TABLE Roles
(
	EmpId INT CONSTRAINT PK_Role PRIMARY KEY IDENTITY (1,1),
	EmpName VARCHAR(50) NOT NULL,
	RoleType BIT CONSTRAINT CK_Role_RoleType CHECK (RoleType IN (1,0)) NOT NULL 
)

SET IDENTITY_INSERT Roles ON
INSERT INTO Roles(EmpId, EmpName, RoleType) VALUES (1,'Alethia Few', 1)
INSERT INTO Roles(EmpId, EmpName, RoleType) VALUES (2, 'Vella Kahler', 0)
INSERT INTO Roles(EmpId, EmpName, RoleType) VALUES (3, 'Elias Strayhorn', 0)
INSERT INTO Roles(EmpId, EmpName, RoleType) VALUES (4, 'Natalia Vidaurri', 0)
INSERT INTO Roles(EmpId, EmpName, RoleType) VALUES (5, 'Micha Wedel', 0)
INSERT INTO Roles(EmpId, EmpName, RoleType) VALUES (6, 'Darren Kohl', 0)
SET IDENTITY_INSERT Roles OFF


CREATE TABLE Reservations
(
	ReservationId INT CONSTRAINT PK_Reservations PRIMARY KEY IDENTITY (1,1),
	ReservedBy INT CONSTRAINT FK_Reservations_Roles REFERENCES Roles(EmpId) NOT NULL,
	ReservedOn DATE DEFAULT GETDATE() NOT NULL,
	[Status] INT CONSTRAINT CK_Status CHECK ([Status] IN (0,1,-1)) DEFAULT 0,
	[SlotId] INT CONSTRAINT FK_Reservations_BookingSlots REFERENCES BookingSlots(SlotId) NOT NULL
)
GO

SET IDENTITY_INSERT Reservations ON
INSERT INTO Reservations(ReservationId, ReservedBy, ReservedOn, [Status], SlotId) VALUES(1, 2,GETDATE(),1, 3)
INSERT INTO Reservations(ReservationId, ReservedBy, ReservedOn, [Status], SlotId) VALUES(2, 1,GETDATE(),1, 2)
INSERT INTO Reservations(ReservationId, ReservedBy, ReservedOn, [Status], SlotId) VALUES(3, 1,GETDATE()+4,1, 2)
INSERT INTO Reservations(ReservationId, ReservedBy, ReservedOn, [Status], SlotId) VALUES(4, 2,GETDATE()+5,-1, 2)
INSERT INTO Reservations(ReservationId, ReservedBy, ReservedOn, [Status], SlotId) VALUES(5, 2,GETDATE()+5,-1, 3)
SET IDENTITY_INSERT Reservations OFF
GO


CREATE PROC usp_BookSlots
	@SlotId INT,
	@EmpId INT,
	@ReservationId INT OUT
AS
BEGIN
    SET @ReservationId = 0
	BEGIN TRY
		IF NOT EXISTS (SELECT * FROM BookingSlots WHERE SlotId = @SlotId) 
			RETURN -1
		IF NOT EXISTS (SELECT * FROM Roles WHERE EmpId = @EmpId) 
			RETURN -2
		INSERT INTO Reservations VALUES (@EmpId, GETDATE(), DEFAULT, @SlotId)
		SET @ReservationId = IDENT_CURRENT('Reservations')
		RETURN 1
	END TRY
	BEGIN CATCH
	    SET @ReservationId = 0
		RETURN -99
	END CATCH
END
GO
--DECLARE @RetValue INT
--DECLARE @ReservationId INT
--EXEC @RetValue = usp_BookSlots 1, 2, @ReservationId OUT
--SELECT @RetValue, @ReservationId

CREATE FUNCTION ufn_FetchAllRejectedSlots()
RETURNS TABLE
AS
	RETURN SELECT r.ReservationId, rs.EmpName, r.ReservedOn, r.SlotId, b.SlotStartTime, b.SlotEndTime 
		   FROM Reservations r INNER JOIN BookingSlots b
		   ON r.SlotId = b.SlotId 
		   INNER JOIN Roles rs
		   ON r.ReservedBy = rs.EmpId
		   WHERE r.Status = -1
GO
--SELECT * FROM ufn_FetchAllRejectedSlots()


CREATE FUNCTION ufn_GetAdminName()
RETURNS VARCHAR(50)
AS
BEGIN
	DECLARE @EmpName VARCHAR(50)
	IF NOT EXISTS(SELECT EmpId FROM Roles WHERE RoleType = 1)
		SET @EmpName ='Not an Admin'	
	ELSE
		SELECT @EmpName = EmpName FROM Roles WHERE RoleType = 1
	RETURN @EmpName
END
GO

--SELECT dbo.ufn_GetAdminName()

GO
SELECT * FROM Roles
SELECT * FROM BookingSlots
SELECT * FROM Reservations